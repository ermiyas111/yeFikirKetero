package com.aden.yefikirketero.retrofit;

import com.aden.yefikirketero.retrofit.model.Person;
import com.aden.yefikirketero.retrofit.model.Post;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface YeFikirKeteroApi {

    String BASE_URL = "http://192.168.43.226:3000";

    @Headers("Content-Type: application/json")
    @GET("posts")
    Call<List<Post>> getPosts();

    @Headers("Content-Type: application/json")
    @GET("get_phone_notifications/251904132755/{limit}")
    Call<List<Person>> getPhoneNotifications(
            @Path("limit") int calculatedLimit
    );

    @Headers("Content-Type: application/json")
    @GET("received_requests/251904132755/{limit}")
    Call<List<Person>> getReceivedRequests(
            @Path("limit") int calculatedLimit
    );
}
