package com.aden.yefikirketero.UI;

public interface OnLoadMoreListener {
    void onLoadMore();
}
